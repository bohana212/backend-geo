<?php
/**
 * Salin file ini menjadi config.php lalu isi dengan nilai kamu sendiri.
 * JANGAN upload config.php ke repo publik.
 */

// URL backend Vercel (Telegram backend), TANPA garis miring di akhir.
define('TG_BACKEND_URL', 'https://backend-geo-48gm.vercel.app');

// Harus SAMA PERSIS dengan MASTER_API_KEY di Environment Variables Vercel.
define('TG_MASTER_API_KEY', 'ganti-dengan-master-api-key-vercel-kamu');

// String acak untuk session/CSRF. Isi bebas, panjang, dan rahasia.
define('SESSION_SALT', 'ganti-dengan-string-acak-panjang');
