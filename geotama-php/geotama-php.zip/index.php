<?php
require_once __DIR__ . '/includes/common.php';

$S = get_settings();
$storeName = $S['store_name'] ?: 'GEOTAMA COMPUTER';
$bio = $S['bio'] ?: 'Solusi komputer, laptop, networking dan kebutuhan IT.';
$wa = wa_number($S['whatsapp'] ?: $S['phone']);
$waBase = $wa ? "https://wa.me/$wa" : '#';
$generalWaText = "Halo $storeName, saya ingin bertanya mengenai produk komputer.";
$generalWa = $wa ? $waBase . '?text=' . rawurlencode($generalWaText) : '#';

$allProducts = get_products();
$products = [];
foreach ($allProducts as $i => $p) {
    $stock = (int) ($p['stock'] ?? 0);
    $status = catalog_status($stock);
    $price = (float) ($p['price'] ?? 0);
    $category = (string) ($p['category'] ?? 'Lainnya');
    $sku = (string) ($p['sku'] ?? $p['code'] ?? '');
    $name = (string) ($p['name'] ?? 'Produk');
    $desc = product_description($p) ?: 'Produk komputer berkualitas.';
    $image = (string) ($p['image'] ?? $p['image_url'] ?? '');

    $waText = "Halo $storeName, saya tertarik dengan produk:\n\nNama: $name\nHarga: " . rupiah($price) . "\n\nApakah produk ini masih tersedia?";
    $products[] = [
        'key' => (string) ($p['id'] ?? $i), 'name' => $name, 'category' => $category, 'description' => $desc,
        'price' => $price, 'priceText' => rupiah($price), 'stock' => $stock, 'image' => $image, 'sku' => $sku,
        'flash' => is_flash($p), 'statusLabel' => $status['label'], 'statusClass' => $status['cls'], 'statusIcon' => $status['icon'],
        'waHref' => $wa ? $waBase . '?text=' . rawurlencode($waText) : '#',
        'search' => mb_strtolower(implode(' ', [$name, $category, $desc, $p['brand'] ?? '', $sku])),
    ];
}

$totalReady = count(array_filter($products, fn($p) => $p['stock'] > 0));
$totalFlash = count(array_filter($products, fn($p) => $p['flash']));
$totalRestock = count(array_filter($products, fn($p) => $p['stock'] > 0 && $p['stock'] <= 3));
$stats = [
    ['icon' => 'fa-box', 'value' => count($products), 'label' => 'Produk'],
    ['icon' => 'fa-circle-check', 'value' => $totalReady, 'label' => 'Ready Stock'],
    ['icon' => 'fa-bolt', 'value' => $totalFlash, 'label' => 'Flash Sale'],
    ['icon' => 'fa-truck-fast', 'value' => $totalRestock, 'label' => 'Stok Terbatas'],
];

function maps_url(string $q): string { return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode($q); }
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($storeName) ?> — Computer Store</title>
<meta name="description" content="<?= h($storeName) ?> — Computer Store, Laptop, PC, Printer, Networking dan kebutuhan IT.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Manrope:wght@400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link rel="stylesheet" href="assets/catalog.css">
</head>
<body>

<header class="navbar">
  <div class="container nav-inner">
    <a href="index.php" class="brand">
      <div class="brand-logo"><i class="fa-solid fa-microchip"></i></div>
      <div class="brand-text">
        <div class="brand-name"><?= h($storeName) ?></div>
        <div class="brand-sub">Computer Store &amp; IT Solution</div>
      </div>
    </a>
    <nav class="nav-links">
      <a href="#produk" class="nav-link">Produk</a>
      <a href="#tentang" class="nav-link">Tentang</a>
      <a href="#kontak" class="nav-link">Kontak</a>
      <a href="login.php" class="nav-admin" title="Login Admin"><i class="fa-solid fa-user-shield"></i><span>Admin</span></a>
    </nav>
  </div>
</header>

<main>
  <section class="hero">
    <div class="container">
      <div class="hero-grid">
        <div>
          <div class="hero-badge"><i class="fa-solid fa-circle-check"></i> Ready Stock • Original Product</div>
          <h1>Upgrade<span>Your Digital Life.</span></h1>
          <p><?= h($bio) ?> Temukan laptop, PC, monitor, printer, sparepart, networking dan berbagai kebutuhan komputer lainnya di <?= h($storeName) ?>.</p>
          <div class="hero-actions">
            <a href="#produk" class="btn btn-primary"><i class="fa-solid fa-store"></i> Lihat Produk</a>
            <?php if ($wa): ?><a href="<?= h($generalWa) ?>" target="_blank" rel="noopener" class="btn btn-outline"><i class="fa-brands fa-whatsapp"></i> Chat WhatsApp</a><?php endif; ?>
          </div>
        </div>
        <div class="hero-card">
          <div class="hero-card-icon"><i class="fa-solid fa-shield-halved"></i></div>
          <h3>Belanja Lebih Mudah</h3>
          <p>Pilih produk, cek stok, lalu langsung hubungi kami melalui WhatsApp.</p>
          <div class="hero-card-info">
            <?php if ($S['address']): ?><div class="info-row"><i class="fa-solid fa-location-dot"></i><a href="<?= h(maps_url($S['address'])) ?>" target="_blank" rel="noopener"><?= h($S['address']) ?></a></div><?php endif; ?>
            <?php if ($S['email']): ?><div class="info-row"><i class="fa-solid fa-envelope"></i><a href="mailto:<?= h($S['email']) ?>"><?= h($S['email']) ?></a></div><?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section>
    <div class="container">
      <div class="stats">
        <?php foreach ($stats as $s): ?>
          <div class="stat">
            <div class="stat-icon"><i class="fa-solid <?= h($s['icon']) ?>"></i></div>
            <div class="stat-number"><?= (int) $s['value'] ?></div>
            <div class="stat-label"><?= h($s['label']) ?></div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <section class="section" id="produk">
    <div class="container">
      <div class="section-head">
        <div><h2 class="section-title">Produk Pilihan</h2><p class="section-desc">Cari kebutuhan komputer kamu dengan mudah.</p></div>
      </div>

      <div class="catalog-toolbar">
        <div class="search-box">
          <i class="fa-solid fa-magnifying-glass"></i>
          <input type="search" id="search-input" placeholder="Cari laptop, PC, RAM, SSD, printer..." autocomplete="off">
        </div>
      </div>

      <div class="category-list" id="category-list">
        <button type="button" class="category-btn active" data-cat="all">Semua</button>
        <?php foreach (CATEGORIES as $c): ?>
          <button type="button" class="category-btn" data-cat="<?= h(strtolower($c)) ?>"><?= h($c) ?></button>
        <?php endforeach; ?>
      </div>

      <div class="product-grid" id="product-grid" style="margin-top:20px">
        <?php foreach ($products as $p): ?>
          <article class="product-card" data-cat="<?= h(strtolower($p['category'])) ?>" data-search="<?= h($p['search']) ?>">
            <div class="product-image">
              <?php if ($p['flash']): ?><div class="product-badge badge-flash"><i class="fa-solid fa-bolt"></i> Flash Sale</div><?php endif; ?>
              <div class="product-status <?= h($p['statusClass']) ?>"><i class="fa-solid <?= h($p['statusIcon']) ?>"></i> <?= h($p['statusLabel']) ?></div>
              <?php if ($p['image']): ?>
                <img src="<?= h($p['image']) ?>" alt="<?= h($p['name']) ?>" loading="lazy" onerror="this.closest('.product-image').innerHTML+='<div class=&quot;no-image&quot;><i class=&quot;fa-solid fa-image&quot;></i></div>';this.remove()">
              <?php else: ?>
                <div class="no-image"><i class="fa-solid fa-computer"></i></div>
              <?php endif; ?>
            </div>
            <div class="product-body">
              <div class="product-category"><?= h($p['category']) ?></div>
              <h3 class="product-name"><?= h($p['name']) ?></h3>
              <p class="product-description"><?= h($p['description']) ?></p>
              <div class="product-price"><?= h($p['priceText']) ?></div>
              <div class="product-stock">
                <span><i class="fa-solid fa-box"></i> Stok: <?= (int) $p['stock'] ?></span>
                <?php if ($p['sku']): ?><span><?= h($p['sku']) ?></span><?php endif; ?>
              </div>
              <div class="product-actions">
                <?php if ($p['stock'] > 0 && $p['waHref'] !== '#'): ?>
                  <a href="<?= h($p['waHref']) ?>" target="_blank" rel="noopener" class="buy-btn"
                     onclick="gtNotify('wa','<?= h(addslashes($p['name'])) ?>','<?= h(addslashes($p['priceText'])) ?>','<?= h(addslashes($p['sku'])) ?>')">
                    <i class="fa-brands fa-whatsapp"></i> Tanya / Pesan
                  </a>
                <?php else: ?>
                  <a href="#" class="buy-btn disabled" onclick="return false"><i class="fa-solid fa-ban"></i> Stok Habis</a>
                <?php endif; ?>
                <button type="button" class="detail-btn" title="Lihat detail" onclick='gtShowDetail(<?= json_encode($p, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>)'><i class="fa-solid fa-eye"></i></button>
              </div>
            </div>
          </article>
        <?php endforeach; ?>
      </div>

      <div class="empty" id="empty-state"><i class="fa-solid fa-box-open"></i><h3>Produk tidak ditemukan</h3><p>Coba gunakan kata pencarian lain atau pilih kategori berbeda.</p></div>
    </div>
  </section>

  <section class="section" id="tentang">
    <div class="container">
      <div class="contact-box">
        <div>
          <div class="hero-badge"><i class="fa-solid fa-circle-info"></i> Tentang <?= h($storeName) ?></div>
          <h2>Solusi Lengkap Perangkat IT.</h2>
          <p><?= h($bio) ?> Kami menyediakan berbagai kebutuhan komputer dan perangkat IT mulai dari laptop, PC, monitor, printer, sparepart, networking hingga CCTV.</p>
        </div>
        <div class="contact-info">
          <?php foreach ([$S['address'], $S['address2']] as $addr): if (!$addr) continue; ?>
            <a href="<?= h(maps_url($addr)) ?>" target="_blank" rel="noopener" class="contact-item"><i class="fa-solid fa-location-dot"></i><span><?= h($addr) ?></span></a>
          <?php endforeach; ?>
          <?php if ($S['facebook']): ?><a href="<?= h($S['facebook']) ?>" target="_blank" rel="noopener" class="contact-item"><i class="fa-brands fa-facebook"></i><span>Facebook</span></a><?php endif; ?>
        </div>
      </div>
    </div>
  </section>

  <section class="section" id="kontak">
    <div class="container">
      <div class="section-head"><div><h2 class="section-title">Hubungi Kami</h2><p class="section-desc">Butuh konsultasi atau ingin cek produk? Langsung hubungi tim kami.</p></div></div>
      <div class="contact-box">
        <div>
          <h2>Siap bantu kebutuhan IT kamu.</h2>
          <p>Konsultasikan kebutuhan komputer, upgrade, printer, networking, maintenance dan kebutuhan IT lainnya.</p>
          <div class="hero-actions" style="margin-top:20px">
            <?php if ($wa): ?><a href="<?= h($generalWa) ?>" target="_blank" rel="noopener" class="btn btn-primary"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a><?php endif; ?>
            <?php if ($S['email']): ?><a href="mailto:<?= h($S['email']) ?>" class="btn btn-outline"><i class="fa-solid fa-envelope"></i> Email</a><?php endif; ?>
          </div>
        </div>
        <div class="contact-info">
          <?php if ($S['instagram']): ?><a href="<?= h($S['instagram']) ?>" target="_blank" rel="noopener" class="contact-item"><i class="fa-brands fa-instagram"></i><span>Instagram</span></a><?php endif; ?>
          <?php if ($S['facebook']): ?><a href="<?= h($S['facebook']) ?>" target="_blank" rel="noopener" class="contact-item"><i class="fa-brands fa-facebook"></i><span>Facebook</span></a><?php endif; ?>
          <?php if ($S['tiktok']): ?><a href="<?= h($S['tiktok']) ?>" target="_blank" rel="noopener" class="contact-item"><i class="fa-brands fa-tiktok"></i><span>TikTok</span></a><?php endif; ?>
        </div>
      </div>
    </div>
  </section>
</main>

<footer class="footer">
  <div class="container footer-inner">
    <div>© <?= date('Y') ?> <?= h($storeName) ?>. All rights reserved.</div>
    <div class="socials">
      <?php if ($S['instagram']): ?><a href="<?= h($S['instagram']) ?>" target="_blank" rel="noopener" class="social" title="Instagram"><i class="fa-brands fa-instagram"></i></a><?php endif; ?>
      <?php if ($S['facebook']): ?><a href="<?= h($S['facebook']) ?>" target="_blank" rel="noopener" class="social" title="Facebook"><i class="fa-brands fa-facebook"></i></a><?php endif; ?>
      <?php if ($S['tiktok']): ?><a href="<?= h($S['tiktok']) ?>" target="_blank" rel="noopener" class="social" title="TikTok"><i class="fa-brands fa-tiktok"></i></a><?php endif; ?>
    </div>
  </div>
</footer>

<?php if ($wa): ?><a href="<?= h($generalWa) ?>" target="_blank" rel="noopener" class="float-wa" title="Chat WhatsApp"><i class="fa-brands fa-whatsapp"></i></a><?php endif; ?>

<div class="modal" id="detail-modal">
  <div class="modal-box">
    <div class="modal-head">
      <div class="modal-title">Detail Produk</div>
      <button type="button" class="modal-close" onclick="gtCloseDetail()"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-content" id="modal-content"></div>
  </div>
</div>

<script>
// ---------- Search & filter (tanpa reload) ----------
const searchInput = document.getElementById('search-input');
const categoryList = document.getElementById('category-list');
const grid = document.getElementById('product-grid');
const emptyState = document.getElementById('empty-state');
let activeCat = 'all';

function applyFilter() {
  const q = searchInput.value.trim().toLowerCase();
  let visible = 0;
  grid.querySelectorAll('.product-card').forEach(card => {
    const matchCat = activeCat === 'all' || card.dataset.cat === activeCat;
    const matchQ = q === '' || card.dataset.search.includes(q);
    const show = matchCat && matchQ;
    card.style.display = show ? '' : 'none';
    if (show) visible++;
  });
  emptyState.classList.toggle('show', visible === 0);
}
searchInput.addEventListener('input', applyFilter);
categoryList.addEventListener('click', e => {
  const btn = e.target.closest('.category-btn');
  if (!btn) return;
  categoryList.querySelectorAll('.category-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  activeCat = btn.dataset.cat;
  applyFilter();
});

// ---------- Notify backend (fire-and-forget) ----------
function gtNotify(type, name, price, sku) {
  try {
    const data = new FormData();
    data.append('type', type); data.append('name', name); data.append('price', price); data.append('sku', sku);
    navigator.sendBeacon('notify.php', data);
  } catch (e) { /* jangan sampai mengganggu link WhatsApp */ }
}

// ---------- Modal detail produk ----------
const modal = document.getElementById('detail-modal');
const modalContent = document.getElementById('modal-content');
function gtShowDetail(p) {
  modalContent.innerHTML = `
    ${p.image ? `<img src="${p.image}" class="modal-product-image" alt="">` : `<div class="modal-product-image" style="display:grid;place-items:center;color:#60a5fa;font-size:55px"><i class="fa-solid fa-computer"></i></div>`}
    <div class="product-category">${p.category}</div>
    <div class="modal-product-name">${p.name}</div>
    <div class="modal-product-price">${p.priceText}</div>
    <div class="modal-product-desc">${p.description}</div>
    <div style="margin-top:18px;color:#94a3b8;font-size:12px"><i class="fa-solid fa-box"></i> Stok tersedia: <strong style="color:white">${p.stock}</strong></div>
  `;
  modal.classList.add('show');
  document.body.style.overflow = 'hidden';
}
function gtCloseDetail() {
  modal.classList.remove('show');
  document.body.style.overflow = '';
}
modal.addEventListener('click', e => { if (e.target === modal) gtCloseDetail(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') gtCloseDetail(); });
</script>
</body>
</html>
